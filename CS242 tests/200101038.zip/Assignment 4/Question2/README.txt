## QUESTION 2 in CS242 ASSIGNMENT 4
## SUBMITTED BY: GUNJAN DHANUKA
## ROLL: 200101038
## DATE: 17/11/2021

Prepare the LaTeX document for the 2 files provided in the attachments.

---------------------------------------------

Steps to execute:
Open Terminal in the directory where 200101038.py file is present.


For First File:
    Type: $ pdflatex 200101038_1.tex
    Type: $ pdflatex 200101038_1.tex

For Second File:
    Type: $ pdflatex 200101038_2.tex
    Type: $ pdflatex 200101038_2.tex

-----------------------------------------------
This will generate a 200101038_1.pdf and 200101038_2.pdf files in the same directory. 
Open the PDF's using PDF viewer of your choice.
-----------------------------------------------

NOTE: PLEASE RUN THE 'pdflatex 200101038_1.tex' TWICE as mentioned above. Simiar for 'pdflatex 200101038_2.tex'. 
    This is because there are hyperlinks in the document which need to run twice to be linked successfully.
    This requires the command to be run twice to successfully link the equations to the numbers.
    Running it only once will show '??' in the place of the links. Please run the command TWICE to avoid any ambiguity.
