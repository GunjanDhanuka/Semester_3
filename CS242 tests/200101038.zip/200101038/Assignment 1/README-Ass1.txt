QUESTION 1
-----------

Steps to execute the awk script from terminal:
1. Open terminal in the Assignment 1 directory and enter the following.
2. $ awk -f 200101038_Assign01_Q1.awk data.txt

Output:
dd 1 3
lgse 3 4
mff 4 4
dhd 4 5
zsw 6 6
a 8 8

**THE data.txt file can be changed to check for other test cases as well.


Gunjan Dhanuka
Roll - 200101038