QUESTION 2
------------


The Shell Script is in prg.sh file and the alphabet sequence is stored in the data.txt file.

Steps to run the script:
1. Open terminal in the folder and type the following commands
2. $ chmod +x 200101038_Assign01_Q2.sh (to make the shell script executable)
3. ./200101038_Assign01_Q2.sh <count> <length> < <file with data>
4. Then you need to enter the value of count and length as specified in the question 


Eg:
$ chmod +x 200101038_Assign01_Q2.sh
$ ./200101038_Assign01_Q2.sh 4 10 < data.txt
Output:
q
quuu
quuubbb
quuubbbu
quuubbbuy
quuubbbuyk


**THE data.txt file can be changed to check for other test cases as well.


Gunjan Dhanuka
Roll - 200101038